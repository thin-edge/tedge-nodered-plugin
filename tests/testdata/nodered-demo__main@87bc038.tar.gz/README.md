nodered-demo
============

Demo nodered project

**Warning**

The project is only works with nodered 3.1 and higher!

### About

This is your project's README.md file. It helps users understand what your
project does, how to use it and anything else they may need to know.

The project shows a simple example how to interface with the thin-edge.io interface.
